import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const {searchHarness,station,place,response}=await import(pathToFileURL(resolve(process.argv[2],'tests/helpers/search-ui-harness.mjs')));
const rows=[];
for(const [name,p,s] of [
 ['nested-name',{...place,namedetails:{name:{bad:'value'}},name:'Safe town'},null],
 ['facility-ref',null,{...station,name:null,railway_ref:{bad:'value'}}],
 ['facility-kind',null,{...station,station:{bad:'value'}}],
 ['facility-operator',null,{...station,operator:[{bad:'value'}]}],
 ['facility-name',null,{...station,name:{bad:'value'}}]
]){
 const h=searchHarness({fetcher:async u=>response(u.pathname.endsWith('/facility')?[s||station]:[p||place])});
 await h.submit();rows.push({name,status:h.status(),text:h.results().textContent});h.close();
}
console.log(JSON.stringify(rows,null,2));
