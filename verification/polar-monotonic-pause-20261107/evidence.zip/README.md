# Polar maintenance monotonic provider deadlines, 2026-11-07

PR #413 remote head f2582c6a3bee5677ac11776aa47ac228b9a79c78; tree 31ce09c7110ad779158c55c9adb7f38e14bee205. Parent main d6b77806e8b659be81f849b9556d268aac9e5b3c, tree f4f525d8ba7092da955812c39eb6d835c7e8285b, includes independently qualified/merged #411 and #412. Local commit dda3640f349144961abeb82b1418cf37b9fbf259 has identical final tree. All three published blobs and entire tree compared exactly. No blocked #409/#410 code.

Node24.22.1, Python3.12.14, Linux x64. Existing authorized dependencies reused, no installation. Host Asia/Tokyo, synthetic test clocks. No real provider requests, acquisition, dispatch, schedule or gate changes.

Outcome: polar helper uses wall time only to parse calendar headers; provider deadlines and normal backoff use elapsed time. Body time consumes the provider pause; early retry timer wakes are rechecked. Separate origins, four attempts, 15-minute cap, five-minute timeout, classification, queries, cache fallback and atomic publication unchanged.

Portable offline independent negative: ATLAS_REPO=<checkout> node --test portable-diagnostic.mjs. Six cases, five expected failures, one body-time control pass. Final six regression/control cases also added to existing fixture harness. Unchanged helper plus final fixtures: node --test tests/polar-fetch.test.mjs; 37 cases, 32 pass/five expected failures. All 31 old cases and body-time control pass. Failures cover seconds/date header pauses with forward/backward wall corrections and early baseline timer wake. Existing assertions kept intact.

Initial focused polar/parser run: 89/89 pass. Final integrated focused command: node --experimental-vm-modules --test tests/polar*.test.mjs tests/retry-after.test.mjs tests/loading-gauge-builder.test.mjs tests/crossings-builder.test.mjs tests/crossings-changes.test.mjs tests/crossing-checkpoint.test.mjs tests/crossing-request.test.mjs tests/crossing-version.test.mjs. 236/236 pass, no skips, 3077.743892ms. Build, unchanged committed style, helper/app syntax and diff checks pass.

Pre-integration aggregate npm test on #411 plus polar change: FAILED, 3879 reported, 3871 pass, two startup test-process failures, six existing skips, 95606.980558ms. Historical only: not final acceptance. Then #412 was merged locally without conflict before publishing the final current-main source; source and full tree verified.

Final integrated aggregate npm test: FAILED, 3871 reported, 3863 pass, two startup test-process failures (startup-details and startup-status), six existing skips, 95499.90649ms. Preserve both logs, not an aggregate pass. Related Node24 failures reproduced on unchanged earlier source; no OOM or root-cause claim, no retry/concurrency/timeout/gate weakening. Exact-head Node26 CI and Codex remain binding; separately recorded in PR. No renderer/UI changes; no live provider or deployment validation claimed by this local archive.
