// Offline diagnostic. Set ATLAS_REPO to the checkout to test.
import test from 'node:test';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const {createPolarTextFetcher}=await import(pathToFileURL(resolve(process.env.ATLAS_REPO||'.','scripts/polar-fetch.mjs')));
for(const date of [false,true])for(const shift of [3600000,-3600000])test(`${date?'HTTP-date':'seconds'} polar pause across ${shift}ms wall correction`,async()=>{
 let wall=Date.parse('2026-11-06T00:00:00Z'),elapsed=0;const calls=[];
 const read=createPolarTextFetcher({userAgent:'Offline diagnostic',now:()=>wall,clock:()=>elapsed,warn:()=>{},wait:async ms=>{wall+=ms;elapsed+=ms;},fetcher:async()=>{
  calls.push(elapsed);const first=calls.length===1;
  const response=new Response('valid',{headers:first?{'Retry-After':date?new Date(wall+600000).toUTCString():'600'}:{}});
  if(first)response.text=async()=>{wall+=shift;throw Error('synthetic body reset');};
  return response;
 }});
 assert.equal(await read('https://overpass.invalid/offline'),'valid');assert.equal(calls.length,2);assert.equal(calls[1]-calls[0],600000);
});
test('polar transient retry floor is retained when a timer wakes early',async()=>{
 let wall=Date.parse('2026-11-06T00:00:00Z'),elapsed=0,timers=0;const calls=[];
 const read=createPolarTextFetcher({userAgent:'Offline diagnostic',now:()=>wall,clock:()=>elapsed,warn:()=>{},wait:async ms=>{const n=timers++?ms:ms/2;wall+=n;elapsed+=n;},fetcher:async()=>{calls.push(elapsed);return new Response('valid',{status:calls.length===1?503:200});}});
 assert.equal(await read('https://overpass.invalid/offline'),'valid');assert.equal(calls.length,2);assert.equal(calls[1]-calls[0],30000);
});
test('control: body time already consumes the observed polar pause',async()=>{
 let wall=Date.parse('2026-11-06T00:00:00Z'),elapsed=0;const calls=[];
 const read=createPolarTextFetcher({userAgent:'Offline diagnostic',now:()=>wall,clock:()=>elapsed,warn:()=>{},wait:async ms=>{wall+=ms;elapsed+=ms;},fetcher:async()=>{
  calls.push(elapsed);const first=calls.length===1,response=new Response('valid',{headers:first?{'Retry-After':'600'}:{}});
  if(first)response.text=async()=>{wall+=300000;elapsed+=300000;throw Error('synthetic body reset');};return response;
 }});
 assert.equal(await read('https://overpass.invalid/offline'),'valid');assert.equal(calls.length,2);assert.equal(calls[1]-calls[0],600000);
});
