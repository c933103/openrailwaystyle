# Remaining provider calendar validation, 2026-11-07

PR: https://github.com/c933103/openrailwaystyle/pull/407
Source head: 4d7f3a5b90789f6035bbb454aa6c38b27d184bf2
Source tree: 6b9ab071d4a961c5129e500b30280d7c61a28126
Main/base: 20243630f732f6a73686fcf5ad20c970962ea43c, tree 4975eed4dd1961c2f33da4575014eaa53e0d69da
Local baseline commit: 179cefad7d60f8433d8fa4d4248340e7cf249395, the same base tree.
Environment: Linux x64, Node v24.22.1, existing pinned dependencies, host TZ Asia/Tokyo. The new valid-calendar cases explicitly select Asia/Tokyo regardless of host timezone.

## Results
- Final fixture-only negative control on unchanged base source: 252 tests, 188 pass, 64 fail. All 168 pre-existing tests pass. The 84 new tests cover malformed dates and valid IMF/RFC850/asctime. The 64 failures are 60 malformed-date cases and four local-time interpretations of valid asctime.
- Focused final source, including scheduler contracts: 261 tests, all pass.
- npm run build, generated-style equality, changed-source node --check and git diff --check pass.
- First full aggregate: 3865 total, 3857 pass, 2 failed test processes, 6 existing skips, 96783.176729 ms. Startup-details and startup-status reported generic test failed.
- First-run files together in isolation: 114/114 pass, 7644.073693 ms.
- One unchanged full TAP recheck: 3871 total, 3863 pass, 2 failed test processes, 6 existing skips, 94732.242238 ms. Startup-details and startup terminated with SIGKILL. No failed assertion explains the kill.
- Full unchanged base comparison with none of this PR's changes: 3786 total, 3778 pass, 2 failed processes, 6 existing skips, 95173.940109 ms. The same startup-details and startup process SIGKILL failures reproduce on the base. This supports a pre-existing local execution problem; it does not establish the reason for the SIGKILL.
- Local aggregate is NOT claimed passing. Current-head Codex review and required Node 26 CI remain separate, binding merge gates.

## Commands
node --experimental-vm-modules --test --test-reporter=tap tests/street-provider-pause.test.mjs tests/axle-provider-pause.test.mjs tests/loading-gauge-builder.test.mjs tests/polar-fetch.test.mjs tests/heritage-builder.test.mjs tests/power-facility-builder.test.mjs [tests/osm-update-plan.test.mjs on final source]
npm run build
git diff --exit-code -- styles/world.style.json
git diff --check
node --check [each changed .mjs source]
npm test -- --test-reporter=tap  # first full attempt; npm placed reporter after paths and default spec output resulted
node --experimental-vm-modules --test --test-reporter=tap tests/startup-details.test.mjs tests/startup-status.test.mjs
node --experimental-vm-modules --test --test-reporter=tap tests/*.test.mjs  # detailed recheck and unchanged-base comparison

negative.log is the initial test-authoring diagnostic. Its energy full-retry expectation incorrectly assumed 60 seconds; the existing policy is 120 seconds. That new-test expectation was corrected before the source fix. The inconsistent weekday fixture was also made future-dated for every client. negative-corrected.log repeats on unchanged source. negative-final.log uses the final explicit-timezone tests on unchanged source. No existing assertion was weakened, skipped, or removed.

All fetches in these tests are synthetic. No external provider acquisition, workflow dispatch, cancellations, new dependency installation, changed limits, changed acceptance gates, or production data edits were performed. Complete logs, including failures, are preserved here; code is in the application commit, not duplicated in this archive.
