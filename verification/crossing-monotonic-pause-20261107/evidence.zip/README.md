# Crossing provider monotonic deadlines, 2026-11-07

Application PR #411, remote head f029bfb858fce122ed627f31fe4aa404663316d9, tree 61aa4adc90a0f21d659f0087fa16aa9da6c52625. Independent main base abeeb6a5140b9c701247e75411bfea3ab64ca632 (tree 95f96e1e40c93f871ad31c65383270946e9e7489). Local commit 3481c4d2f015941818f90a0bf01d9c2f2c73735a has exactly the same final tree; all five published blobs and full tree were compared before PR publication.

Environment: Linux x86_64, Node24.22.1, Python3.12.14, existing authorized dependency checkout reused without installation. Host Asia/Tokyo; test wall time is synthetic. Tests make no provider requests.

Outcome: use monotonic deadlines and parse provider calendar headers once at receipt. Retain deadlines across body failures/splits, consume body time, and recheck early timer wakes. Preserve spacing/backoff, 5-attempt limit, 15-minute cap, byte budget, failure classification, pinned query time, checkpoint/publication contracts and schedule. Does not claim to repair the observed external Overpass connection outage. No blocked #409/#410 code included.

Negative command: node --experimental-vm-modules --test tests/crossings-builder.test.mjs, with final new fixtures against unchanged main builder. 48 tests: 42 pass, six expected timing failures. All 40 existing cases and two timing controls pass. The other six reproduce wall-clock-forward/backward, HTTP-date/body-error reparsing, retained split pause and early timer wake defects.

Final focused command: node --experimental-vm-modules --test tests/crossings-builder.test.mjs tests/crossings-changes.test.mjs tests/crossing-checkpoint.test.mjs tests/crossing-request.test.mjs tests/crossing-version.test.mjs. 110/110 pass, 1229.27915ms.

Final build/checks: npm run build; git diff --exit-code -- styles/world.style.json; node --check scripts/build-crossings.mjs; node --check styles/app.mjs; git diff --check HEAD^ HEAD. All pass. Existing VM clocks advance elapsed time as timers run; existing assertions remain intact. Source patch and final checks included.

Full final source aggregate: npm test. FAILED, 3855 reported tests, 3846 pass, 3 startup test-process failures (startup-details, startup-status, startup), 6 existing skips, 95742.673836ms. Preserve this failure, not an aggregate pass. Related Node24 process failures were independently reproduced on unchanged earlier source (evidence commit aa0ac5b350e2a9c22890c7ca01bfeee58a233f20); no root-cause or OOM claim. No retries or concurrency/timeout/gate weakening used here. Required Node26 exact-head CI and Codex reviews remain binding, with outcome separately recorded in PR. This archive is local test evidence only, not deployed/live-provider validation.
