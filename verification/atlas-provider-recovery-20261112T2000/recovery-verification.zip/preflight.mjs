// Read-only audit of already-published artifact copies, run from the source checkout.
// Usage: node ../evidence/preflight.mjs ../evidence
import assert from 'node:assert/strict';
import {readFile, writeFile, stat} from 'node:fs/promises';
import {resolve, join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const require = createRequire(resolve('package.json'));
const {VectorTile} = require('@mapbox/vector-tile'), Pbf = require('pbf');
const {checkMarker} = await import(pathToFileURL(resolve('scripts/data-source.mjs')));
const {readTable} = await import(pathToFileURL(resolve('scripts/crossing-rows.mjs')));
const {tilesWorld} = await import(pathToFileURL(resolve('scripts/world-regions.mjs')));
const {TRACTION_FILES} = await import(pathToFileURL(resolve('scripts/build-extract-traction.mjs')));
const root = process.argv[2];
assert(root);
const readJson = async file => JSON.parse(await readFile(file, 'utf8'));
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const report = {mode: 'offline, read-only published-artifact preflight; not a production source switch', datasets: {}};
for (const dataset of ['crossings', 'traction']) {
  const dir = join(root, `${dataset}-extract`), markerText = await readFile(join(dir, 'source.json'), 'utf8');
  assert.equal(checkMarker(markerText, dataset), null);
  const marker = JSON.parse(markerText), tileDir = dataset === 'traction' ? join(dir, 'signals') : dir;
  const manifest = await readJson(join(tileDir, 'manifest.json')), index = await readJson(join(tileDir, 'index.json'));
  assert.equal(manifest.complete, true);
  assert.equal(manifest.extract.regions, 175);
  assert.deepEqual(manifest.extract.missingRegions, []);
  assert.equal(index.tiles.length, manifest.tiles);
  assert.equal(new Set(index.tiles).size, index.tiles.length);
  let tileBytes = 0, tileFeatures = 0;
  const tileHash = createHash('sha256');
  for (const key of index.tiles) {
    assert.match(key, /^\d+\/\d+\/\d+$/);
    const bytes = await readFile(join(tileDir, `${key}.pbf.gz`));
    tileBytes += bytes.length; tileHash.update(`${key}\0${digest(bytes)}\n`);
    const tile = new VectorTile(new Pbf(gunzipSync(bytes)));
    assert(Object.keys(tile.layers).length);
    for (const layer of Object.values(tile.layers)) {
      for (let i = 0; i < layer.length; i++) {
        const feature = layer.feature(i); assert(feature.type >= 1 && feature.type <= 3);
        const geometry = feature.loadGeometry(); assert(geometry.length);
        for (const line of geometry) for (const point of line) assert(Number.isFinite(point.x) && Number.isFinite(point.y));
        tileFeatures++;
      }
    }
  }
  const item = {marker, manifest, tileCount: index.tiles.length, tileBytes, decodedTileFeatures: tileFeatures, tileContentInventorySha256: tileHash.digest('hex')};
  if (dataset === 'crossings') {
    assert.equal(tileBytes, manifest.tileBytes);
    const bytes = await readFile(join(dir, 'crossings.tsv.gz'));
    const text = gunzipSync(bytes).toString(), table = readTable(text);
    assert.equal(table.size, manifest.crossings);
    assert.equal(text.split('\n').filter(Boolean).length, table.size, 'duplicate table IDs');
    let road = 0, pedestrian = 0, minor = 0;
    for (const [id, row] of table) {
      const [lat, lon, kind, isMinor] = row;
      assert(Number.isSafeInteger(id) && id > 0);
      assert(Number.isFinite(lat) && Math.abs(lat) <= 90 && Number.isFinite(lon) && Math.abs(lon) <= 180);
      assert(['road', 'foot'].includes(kind)); assert.equal(typeof isMinor, 'boolean');
      kind === 'road' ? road++ : pedestrian++; if (isMinor) minor++;
    }
    assert.equal(road, manifest.road); assert.equal(pedestrian, manifest.pedestrian); assert.equal(minor, manifest.onMinorTracksOnly);
    Object.assign(item, {tableRows: table.size, road, pedestrian, minor, tableGzipSha256: digest(bytes)});
  } else {
    for (const file of TRACTION_FILES) assert((await stat(join(dir, file))).isFile());
    item.collections = [];
    for (const [name, manifestName, countField] of [
      ['signals/railway-signals', 'signals/manifest.json', 'signals'],
      ['power/power-facilities', 'power/manifest.json', 'features'],
      ['power/electricity-signals', 'power/electricity-signals-manifest.json', 'features'],
      ['power/power-methods', 'power/methods-manifest.json', 'features'],
    ]) {
      const metadata = await readJson(join(dir, manifestName));
      assert.equal(metadata.complete, true);
      if (metadata.coverage) assert(tilesWorld(metadata.coverage.map(x => x.bbox)));
      const bytes = await readFile(join(dir, `${name}.geojson.gz`)), geo = JSON.parse(gunzipSync(bytes));
      assert.equal(geo.type, 'FeatureCollection'); assert.equal(geo.features.length, metadata[countField]);
      const ids = new Set();
      const coordinates = value => {
        assert(Array.isArray(value) && value.length);
        if (typeof value[0] === 'number') {
          assert(value.length >= 2 && Number.isFinite(value[0]) && Math.abs(value[0]) <= 180 && Number.isFinite(value[1]) && Math.abs(value[1]) <= 90);
        } else for (const child of value) coordinates(child);
      };
      for (const feature of geo.features) {
        assert.equal(feature.type, 'Feature'); assert(feature.id !== undefined && !ids.has(feature.id)); ids.add(feature.id);
        assert(['Point', 'MultiPoint', 'LineString', 'MultiLineString', 'Polygon', 'MultiPolygon'].includes(feature.geometry?.type));
        coordinates(feature.geometry.coordinates);
      }
      item.collections.push({name, features: geo.features.length, gzipSha256: digest(bytes), completeCoverage: metadata.coverage ? true : 'source assembly', metadata});
    }
  }
  report.datasets[dataset] = item;
  console.log(JSON.stringify({dataset, tiles: item.tileCount, rows: item.tableRows, collections: item.collections?.map(x => ({name: x.name, features: x.features}))}));
}
await writeFile(join(root, 'extract-preflight.json'), JSON.stringify(report, null, 2) + '\n');
