# Loading-gauge monotonic provider deadlines, 2026-11-07

PR #412 remote head 7d0772787d0f6308af22eb2b4cacb3d90cb612a8; tree b6115d6d3536004c9cf201dca2b047ed47a79b5b. Parent abeeb6a5140b9c701247e75411bfea3ab64ca632, tree 95f96e1e40c93f871ad31c65383270946e9e7489. Local commit d60ef06 has the identical final tree. All three published blobs and full tree verified.

Environment Node24.22.1, Python3.12.14, Linux x64. Existing dependency directory reused; no dependency installation. Host Asia/Tokyo, tests use synthetic wall and elapsed time. No provider requests or acquisition, workflow dispatch, schedule or gate changes.

Outcome: capture provider pause on monotonic time and recheck early timer wakes before either initial request or retry. Preserve three attempts, initial five-second pause, one-minute baseline, 15-minute provider cap, classification, query, cache fallback and complete success publication. Body time consumes the observed pause. No pending browser or crossing repair is included in this independent application head.

Negative: node --test tests/loading-gauge-builder.test.mjs, new final fixtures against unchanged main builder. 37 tests, 31 pass/six expected failures. All 29 existing tests and two body-time controls pass. Failures reproduce forward/backward corrections (seconds and HTTP-date) and early provider/initial timer wakes.

Final focused: node --test tests/loading-gauge-builder.test.mjs tests/retry-after.test.mjs tests/extract-filter.test.mjs. 45 reported, 44 pass, zero fail, one existing skip, 2759.622501ms. No assertions weakened or new skips.

Build/checks: npm run build; git diff --exit-code -- styles/world.style.json; node --check scripts/build-loading-gauge-list.mjs; node --check styles/app.mjs; git diff --check HEAD^ HEAD. All pass.

Full aggregate npm test FAILED: 3854 reported, 3846 pass, two startup test-process failures (startup-details and startup-status), six existing skips, 96597.928914ms. Complete log retained, not an aggregate pass. Related Node24 process failures also occurred on unchanged earlier source; no OOM or specific root-cause claim. No aggregate retries/concurrency or timeout changes. Required exact-head Node26 CI and Codex remain binding and their results will be recorded separately in the PR.
