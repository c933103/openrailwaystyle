# Heritage monotonic deadlines, PR #415

Remote head 6398d02bca20dea02b6feaccd7d6ebd4e01e426a; tree 1cdf3203302fbae95aaac3757deaf3984d961c76, three changed files. Local commit e46259a0e602f9e9e85c9ccd46842f5c4b9e4e9d has identical tree. Independent current-main base, no pending energy #414 changes.

Observed outcome: monotonic header deadlines retained across full retry, changes fallback, query-limit split and success-to-next-region; early provider/local wakes rechecked before consuming deadline. Body time still consumes pause. Four-attempt ceiling, 15-minute cap, byte budget, query/cache identity, classifier, completed cache retention and atomic publication unchanged. Does not claim to fix external provider fetch failures.

Negative command: node --experimental-vm-modules --test tests/heritage-builder.test.mjs, new fixtures with unchanged main builder. 102 cases, 91 pass/11 expected timing failures; all 89 old cases and two body-time controls pass. Fixture body-reader hooks change only synthetic first-read clocks, retaining actual stream reader cancellation and release.

Final focused command: node --experimental-vm-modules --test tests/heritage-builder.test.mjs tests/heritage.test.mjs tests/heritage-workflow.test.mjs tests/retry-after.test.mjs. 114/114 pass, 2395.875981ms. Build, unchanged committed style, builder/app syntax and diff pass.

Final full npm test FAILED: 3899 reported, 3890 pass, three startup test-process failures (startup-details, startup-status, startup), six existing skips, 93799.946721ms. Complete failure log retained; not a full pass. No skipped/newly weakened tests, aggregate retry or concurrency/timeout change.

Environment: Node24.22.1, Python3.12.14, Linux x64; existing dependencies reused, no installation. Host Asia/Tokyo, synthetic fixture clocks. No provider requests, manual acquisition, workflow dispatch or schedule/gate changes. Current-main base b264635d1bf0c2c820dbbd44f2c35af6f790b67d, tree 31ce09c7110ad779158c55c9adb7f38e14bee205. No blocked #409/#410 code. All published source blobs and full tree matched local Git. No local aggregate failure is called a pass, and no OOM/root-cause claim is made. Related startup process failures occurred on unchanged earlier source, but exact-head Node26 CI and Codex remain binding. Independent immutable archives are outside the application branch.
