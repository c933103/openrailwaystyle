# Startup process diagnostic, 2026-11-07

Unchanged application source: abeeb6a5140b9c701247e75411bfea3ab64ca632.
Verified local tree: 95f96e1e40c93f871ad31c65383270946e9e7489.
Environment: Linux x64, Node 24.22.1, existing pinned dependencies. No repository edits, runtime upgrades, external provider requests or changed test assertions were made.

The diagnostic adds an external node:test afterEach hook which logs process.memoryUsage(). It does not change the application or the repository harness. Its source is included as probe.mjs. Tests continue using the existing network-blocked synthetic harness.

A default-concurrency run of startup-details, startup-status and startup reported 148 passed tests and two SIGKILL file failures. Startup-status and startup were killed. The largest reported RSS reading was about 794 MiB; resource.getrusage reported a maximum child RSS of 813,144 KiB. These are per-process/high-water readings, not a measurement of total simultaneous memory. They do not prove why the processes were killed.

Running the same three files separately, one process after another, passed all 169 tests: 62 startup-details, 52 startup-status and 55 startup. Cumulative maximum child RSS was 814,416, 853,764 and 908,508 KiB respectively. The isolated comparison is diagnostic only. It does not replace or pass the repository's full aggregate command, and no CI or acceptance gate was changed.

This narrows the earlier local aggregate SIGKILL issue to execution conditions: the same tests pass in isolation and in required Node 26 CI. A future fix should address memory retention or test-process design with preserved assertions and independent review, rather than masking failures or claiming a root cause from SIGKILL alone.

Commands:
node --experimental-vm-modules --import ./probe.mjs --test --test-reporter=tap tests/startup-details.test.mjs tests/startup-status.test.mjs tests/startup.test.mjs
node --experimental-vm-modules --import ./probe.mjs --test --test-reporter=tap tests/<each of those three files>.test.mjs

Python subprocess.run and resource.getrusage collected exit status, elapsed time and child RSS around those commands. Baseline and isolated logs are included in full. No broader dataset freshness or deployment claim is made by this diagnostic.
