import {afterEach} from 'node:test';
afterEach(t=>{const m=process.memoryUsage();console.log('STARTUP_MEMORY '+JSON.stringify({test:t.name,rss:m.rss,heapUsed:m.heapUsed,heapTotal:m.heapTotal}));});
