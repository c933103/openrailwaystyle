# Timetable provider calendar verification, 2026-11-07

PR: https://github.com/c933103/openrailwaystyle/pull/408
Source: 766bd4932fe8ffc80e8563ce569a62601e508abc
Tree: 95f96e1e40c93f871ad31c65383270946e9e7489
Parent main: 3182876b8fd3c1f94f7163afcf1b02e7b3e2449b
Parent tree: 6b9ab071d4a961c5129e500b30280d7c61a28126

Linux x64, Node 24.22.1, Python 3.12, existing pinned dependencies. Tests use only synthetic publisher responses and loopback fixture servers, never provider acquisition.

Four new methods cover malformed calendars/weekdays, valid UTC obsolete date forms, exact rolling-century interpretation and both prevented false receipts and retained valid deadlines. Final negative control on unchanged source: 11 focused methods, 11 assertion/subtest failures across the four new methods, seven existing methods pass, no errors. Final focused result: 11/11 pass. Full Python acquisition suite: 114/114 pass, 89.156 seconds. Build, style equality, Python compilation and diff checks passed.

Full local aggregate: 3877 total, 3870 pass, one failed startup-details test process killed by SIGKILL, six existing skips, 95,532.235358 milliseconds. It is not a passing local aggregate. Earlier #407 records the same startup SIGKILL problem on unchanged base. Current-head Codex and all required Node 26 CI remain binding and must pass independently.

Commands:
python -m unittest discover -s tests -p global_frequency_test.py -k retry_after
python -m unittest discover -s tests -p global_frequency_test.py
python -m py_compile scripts/global-service-frequency.py tests/global_frequency_test.py
npm run build
git diff --exit-code -- styles/world.style.json
git diff --check
node --experimental-vm-modules --test --test-reporter=tap tests/*.test.mjs

negative.log is the first authoring diagnostic: two malformed-header subcases initially shared a cache, so the first intentionally exposed false retained receipt interfered with the second. Each final subcase has a separate cache. The negative-final.log file reruns the final new fixtures on unchanged source and has only assertion failures. No existing test was weakened or skipped. No production or workflow state was changed by these local checks.
