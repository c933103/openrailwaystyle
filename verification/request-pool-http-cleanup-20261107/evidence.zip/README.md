# Map request-pool HTTP cleanup evidence

Source: c933103/openrailwaystyle PR #409, head 173a5843d0df1f3d612bbc8dec31915b1a220486.
Base: abeeb6a5140b9c701247e75411bfea3ab64ca632.
Tree: dd0b0e60925314d91b06967da31c80bbec1bd30a; all 3 published blobs and tree matched local Git hashes.
Environment: Linux x64, Node 24.22.1, Python 3.12.14; existing pinned dependencies reused, no installation or provider acquisition.

Commands and outcomes:
- Negative unchanged-base source with new tests: node --test tests/request-pool-cooldown.test.mjs. 8 total, 4 pass, 4 fail. Both old cases and new rejection controls pass; pending/throwing cleanup HTTP429/403 each fail their immediate HTTP-policy oracle.
- Focused final: node --test tests/request-pool.test.mjs tests/request-pool-cooldown.test.mjs tests/provider-retry.test.mjs. 30/30 pass, 144.816717ms.
- npm run build; git diff --exit-code -- styles/world.style.json; node --check styles/request-pool.mjs; git diff --check. Passed, style unchanged.
- npm test. FAILED: 3880 reported tests, 3873 pass, 1 failed test process (startup-details), 6 existing skips, 95079.321732ms. No unchanged full rerun or weakened assertion. Spec reporter does not establish the underlying termination cause.
- node --experimental-vm-modules --test tests/startup-details.test.mjs. Isolated diagnostic passed 62/62. This does not replace or relabel the failed aggregate.

The same startup file/process behavior has prior unchanged-base evidence at commit aa0ac5b350e2a9c22890c7ca01bfeee58a233f20 (verification/startup-process-memory-20261107/evidence.zip); diagnosis is not a claimed memory-root-cause proof.
Exact-head Codex and required Node26 CI remain independently required. PR comments carry later CI/review outcomes.

Delta: non-blocking, guarded error-body cancellation plus six compact cooldown/access-policy cases and behavior documentation. No timeout, concurrency, retry count/status classification, cache, provider, acquisition, CI/gate or access changes. Tests use offline synthetic responses only.
