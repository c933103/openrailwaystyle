# Final request-pool cleanup delivery evidence

PR #409 head b129e9a642d9298adeab16561bf8bf99a804929c, tree 1c49bd2b1854ab00ddbe2fc721b834dcdc4bd47d.
First head 173a5843d0df1f3d612bbc8dec31915b1a220486 omitted the asset token; caught before merge. Corrected asset 20261107-request-cleanup-1 is coordinated across the module graph. Existing service-worker cache generation remains unchanged, with no cache purge. All 12 extra blobs and complete tree matched local Git hashes.

Environment: Linux x64, Node24.22.1, Python3.12.14; reused pinned dependencies, no install or provider acquisition.

- node --experimental-vm-modules --test tests/request-pool.test.mjs tests/request-pool-cooldown.test.mjs tests/provider-retry.test.mjs tests/sw-install.test.mjs tests/font-shell.test.mjs tests/station-shell.test.mjs: 116/116 passed,2421.954829ms. Covers current exact app+label-bundle offline delivery, unchanged-token negative, old-tab isolation, best-effort cleanup and full provider pause.
- npm run build; git diff --exit-code -- styles/world.style.json; node --check styles/request-pool.mjs; node --check styles/app.mjs; node --check styles/sw.js; git diff --check: passed. Style unchanged. Temporary proposed SW generation bump was removed before source publication; current unchanged worker was exercised by final shell tests.
- Upgrade regression against first-head source: one expected failure at fresh-token oracle. Initial negative setup attempt lacked node_modules; retained as setup failure, then existing dependencies were symlinked and true negative obtained. No install.
- Intermediate aggregate during asset correction: failed startup-details process,3876pass/1fail/6skip,94811.813969ms. This is not final-source acceptance because the last upgrade regression was added while it ran; preserved for transparency.
- FINAL npm test: FAILED,3860 reported tests,3852pass/2failed file processes/6existing skips,96515.035016ms. startup-details and startup-status process failures. No assertion weakened or unchanged aggregate repeated.
- FINAL two isolated diagnostic commands, run sequentially: node --experimental-vm-modules --test tests/startup-details.test.mjs and same for startup-status: 62/62 and52/52 pass. They do not replace or relabel the aggregate. Root cause not asserted; prior unchanged-base startup process diagnostic is at aa0ac5b350e2a9c22890c7ca01bfeee58a233f20.

Original negative/focused/build/full evidence remains at b553a0bf55357aedf5c5f8b787176549c1554f5f/verification/request-pool-http-cleanup-20261107/evidence.zip. This follow-up archive contains only new logs, not a duplicate historical source bundle.
Current-head Codex code review passed. Required CI still pending at archive time; later PR receipt supplies exact-head CI/merge state. Never treat old-head review/CI as current-head qualification.
