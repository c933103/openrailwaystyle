// CPU-only check of the immutable controller and exact platform-edge fixture.
// Usage: node verify-platform-threshold-cpu.mjs PATH_TO_REPO [COMMIT]
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

const repo=process.argv[2];
if(!repo)throw new Error('Usage: node verify-platform-threshold-cpu.mjs PATH_TO_REPO [COMMIT]');
const rev=process.argv[3]||'33a533e1967156e1589983f911fa3aca2d22050a';
const git=(...args)=>execFileSync('git',['-C',repo,...args],{encoding:'utf8'});
const commit=git('rev-parse',`${rev}^{commit}`).trim(),tree=git('rev-parse',`${rev}^{tree}`).trim();
const source=git('show',`${rev}:styles/platform-length.mjs`),fixtureText=git('show',`${rev}:tests/fixtures/platform-edge.json`);
const sha=text=>createHash('sha256').update(text).digest('hex');
console.log(JSON.stringify({node:process.version,commit,tree,sourceSha256:sha(source),fixtureSha256:sha(fixtureText)}));
const {createPlatformLengths}=await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const fixture=JSON.parse(fixtureText);
for(const [kind,width,height] of [['desktop',1365,900],['mobile',412,915]]){
 let zoom=19,data,requests=0;
 const mercator=([lng,lat])=>[(lng+180)/360,(1-Math.log(Math.tan(Math.PI/4+lat*Math.PI/360))/Math.PI)/2];
 const center=mercator([139.7664,35.6815]);
 const project=lnglat=>{const p=mercator(lnglat),scale=512*2**zoom;return {x:(p[0]-center[0])*scale+width/2,y:(p[1]-center[1])*scale+height/2};};
 const unproject=([x,y])=>{const scale=512*2**zoom,px=(x-width/2)/scale+center[0],py=(y-height/2)/scale+center[1];return {lng:px*360-180,lat:Math.atan(Math.sinh(Math.PI*(1-2*py)))*180/Math.PI};};
 const stableSource={setData:d=>data=d};
 const map={getZoom:()=>zoom,getLayer:()=>undefined,getContainer:()=>({clientWidth:width,clientHeight:height}),project,unproject,queryRenderedFeatures:()=>[fixture.feature],getSource:id=>id==='platformLengths'?stableSource:null};
 const controller=createPlatformLengths(map,{delay:0,fetcher:async()=>{requests++;return {ok:true,status:200,json:async()=>fixture.response};}});
 try{
  controller.update();await new Promise(r=>setTimeout(r,10));
  assert.equal(data.features.length,1);assert.equal(data.features[0].properties.platform_length,fixture.response.properties.length);
  zoom=18;controller.update();
  assert.equal(data.features.length,1);assert.equal(data.features[0].properties.ref,'1');assert.ok(!('platform_length' in data.features[0].properties));assert.equal(requests,1);
  const point=project(data.features[0].geometry.coordinates);assert.ok(point.x>=0&&point.x<=width&&point.y>=0&&point.y<=height);
  console.log(JSON.stringify({kind,zoom,requests,properties:data.features[0].properties,point,result:'PASS'}));
 }finally{controller.destroy();}
}
console.log('LIMIT: mock visible-edge queries and Mercator projection; verifies controller/geometry logic, not browser event/tile timing or the hosted timeout cause.');
