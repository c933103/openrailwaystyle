#!/usr/bin/env python3
"""Verify the approved Pages origin's exact final-source assets, no provider calls."""
import datetime, hashlib, json, pathlib, sys, urllib.request
ROOT = pathlib.Path('/tmp/atlas-oct18-noon/styles')
OUT = pathlib.Path('/tmp/atlas-measure-evidence/production') / sys.argv[1]
OUT.mkdir(parents=True, exist_ok=True)
BASE = 'https://c933103.github.io/openrailwaystyle/'
TOKEN = '20261018-measure-height-state-2'
FILES = ['app.mjs', 'cjk-font.mjs', 'data-check.html', 'data-check.mjs',
         'departures-ui.mjs', 'draw.mjs', 'elevation.mjs', 'index.html',
         'layer-semantics.mjs', 'map-model.mjs', 'sw.js', 'vendor/tile-labels.js']
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError('Unexpected redirect: ' + str(code))
opener = urllib.request.build_opener(NoRedirect)
result = {'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source': '891e97ade75a4f156cc7b752375673e7a6e849aa',
          'tree': 'e2a746da4ccfff8588a61a507cdfd390e10d98d9',
          'assetToken': TOKEN, 'baseUrl': BASE, 'files': []}
failed = False
for name in FILES:
    expected = (ROOT/name).read_bytes()
    url = BASE + name + (('?v=' + TOKEN) if name.endswith('.mjs') or name.startswith('vendor/') else '')
    row = {'path': name, 'url': url, 'expectedBytes': len(expected),
           'expectedSha256': hashlib.sha256(expected).hexdigest()}
    try:
        request = urllib.request.Request(url, headers={'Accept-Encoding': 'identity', 'Cache-Control': 'no-cache'})
        with opener.open(request, timeout=20) as response:
            actual = response.read(2_000_001)
            if len(actual) > 2_000_000: raise RuntimeError('Unexpected oversized asset')
            row.update(status=response.status, contentType=response.headers.get('Content-Type'),
                       finalUrl=response.geturl(), actualBytes=len(actual),
                       actualSha256=hashlib.sha256(actual).hexdigest(),
                       equal=(response.status == 200 and actual == expected))
            dest = OUT/'served'/name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(actual)
    except Exception as error:
        row.update(equal=False, error=str(error))
    failed |= not row['equal']
    result['files'].append(row)
    print(('PASS' if row['equal'] else 'FAIL') + ' ' + name + ' ' + row.get('actualSha256', row.get('error', '')))
result['passed'] = not failed
result['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT/'served-check.json').write_text(json.dumps(result, indent=2) + '\n')
if failed: raise SystemExit(1)

