import {createPlatformLengths, createPlatformTileGeometry} from './source/styles/platform-length.mjs';
const tick = () => new Promise(resolve => setImmediate(resolve));
let zoom = 19, release;
const requests = [], signals = [], completed = [];
const tileGeometry = createPlatformTileGeometry({
  tileURL: () => 'https://fixture.invalid/platform/{z}/{x}/{y}',
  fetcher: async url => {
    requests.push(url);
    if (requests.length === 1) await new Promise(resolve => { release = resolve; });
    return {ok: true, status: 200, arrayBuffer: async () => url};
  },
  decode: url => {
    const x = Number(url.split('/').at(-2));
    return [{id: 'way-40', type: 2, extent: 4096,
      geometry: [[[x === 16384 ? 4090 : 0, 100], [x < 16386 ? 4100 : 100, 100]]]}];
  },
});
const geometry = {measure(id, seeds, signal) { signals.push(signal); return tileGeometry.measure(id, seeds, signal); }};
const feature = {properties: {id: 'way-40'}, geometry: {type: 'LineString', coordinates: [[.0015, .002], [.0035, .002]]}};
const map = {getZoom: () => zoom, getLayer: () => ({}),
  queryRenderedFeatures: ({layers}) => layers.includes('platform-edges') ? [] : [feature],
  getSource: () => ({setData() {}})};
const platform = createPlatformLengths(map, {geometry, delay: 60000,
  fetcher: async () => ({ok: true, json: async () => ({properties: {ref: '1'}})}),
  onPlatform: (id, result) => completed.push({id, length: result.length})});
try {
  platform.update();
  const before = {requests: requests.length, measuring: signals.length};
  zoom = 18; platform.update();
  const cancelled = signals[0].aborted;
  release();
  for (let i = 0; i < 10; i++) await tick();
  console.log(JSON.stringify({before, zoom, cancelled, requests, completed}, null, 2));
} finally { platform.destroy(); }
