import test from 'node:test';
import assert from 'node:assert/strict';
import {cp, mkdir, mkdtemp, readFile, rm, symlink, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join, resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
import {gzipSync, gunzipSync} from 'node:zlib';
import {STAGES, quarters, toFeatures, writeTable as writeBranches} from '/workspace/shared/atlas-next-bug-20261017/source/scripts/branch-lines.mjs';
import {addResult, commitStage, toTable, writeTable as writeServices} from '/workspace/shared/atlas-next-bug-20261017/source/scripts/service-routes.mjs';

const body = {osm3s: {timestamp_osm_base: '2026-10-07T00:00:00Z'}, elements: [
  {type: 'relation', id: 1, version: 1, timestamp: '2026-10-01T00:00:00Z',
    tags: {route: 'subway', ref: '1', name: 'Fixture line', network: 'Fixture'},
    members: [{type: 'way', ref: 10, role: ''}]},
  {type: 'way', id: 10, version: 1, timestamp: '2026-10-01T00:00:00Z',
    tags: {railway: 'subway'}, nodes: [1, 2], geometry: [{lon: 139.7, lat: 35.68}, {lon: 139.71, lat: 35.69}]},
]};
const part = STAGES.find(stage => stage.name === 'japan').parts[0];
const queue = quarters(part.box).slice(0, 2).map(box => ({part: 0, box, depth: 1}));
const pipelines = [
  {name: 'service', script: 'build-service-routes.mjs', folder: 'service-data', tableFile: 'service-routes.ndjson.gz', version: 1,
    table: () => {const table = {routes: new Map(), ways: new Map()}; addResult(table, toTable(body), 'japan'); commitStage(table, 'japan'); return writeServices(table);}},
  {name: 'branch', script: 'build-branch-lines.mjs', folder: 'branch-data', tableFile: 'branch-lines.ndjson.gz', version: 3,
    table: () => writeBranches(new Map(toFeatures(body).map(feature => [feature.id, {...feature, stage: 'japan'}])))},
];

async function fixture(pipeline, fn) {
  const root = await mkdtemp(join(tmpdir(), 'atlas-staged-budget-'));
  try {
    await cp('scripts', join(root, 'scripts'), {recursive: true});
    await mkdir(join(root, 'styles'));
    for (const name of ['pbf-utf8.mjs', 'service-frequency.mjs']) await cp(`styles/${name}`, join(root, 'styles', name));
    await symlink(resolve('node_modules'), join(root, 'node_modules'), 'dir');
    await mkdir(join(root, 'previous'));
    await writeFile(join(root, 'mock.mjs'), `import {readFileSync, appendFileSync} from 'node:fs';
const observations = JSON.parse(readFileSync(process.env.MOCK_PATH, 'utf8')); let count = 0;
const log = event => appendFileSync(process.env.MOCK_EVENTS, JSON.stringify(event) + '\\n');
globalThis.setTimeout = callback => {callback(); return 0;};
globalThis.fetch = async (url, options) => {
  appendFileSync(process.env.MOCK_LOG, JSON.stringify({url, query: options.body.get('data')}) + '\\n');
  const request = count, next = observations[count++]; if (!next) throw new Error('Unexpected fixture request');
  if (next.throw) throw new Error(next.throw);
  const text = next.text ?? JSON.stringify(next.body);
  const buffer = Buffer.from(text.padEnd(next.bytes ?? text.length, ' '));
  if (!next.chunks) return new Response(buffer, {status: next.status ?? 200});
  let offset = 0, chunkIndex = 0;
  return new Response(new ReadableStream({
    pull(controller) {
      if (offset >= buffer.length) { log({request, kind: 'close'}); controller.close(); return; }
      const length = Math.min(next.chunks[chunkIndex++] ?? next.chunkSize ?? 65536, buffer.length - offset);
      log({request, kind: 'chunk', length});
      controller.enqueue(buffer.subarray(offset, offset + length)); offset += length;
    },
    cancel() { log({request, kind: 'cancel', offset}); },
  }, {highWaterMark: 0}), {status: next.status ?? 200});
};`);
    const initial = pipeline.table();
    const run = async (responses, {runs = [], state, previous = initial} = {}) => {
      const prior = state ?? {version: pipeline.version, downloadStages: 3, runs,
        stages: {...Object.fromEntries(STAGES.map(stage => [stage.name, {completed: new Date().toISOString(), pending: null, seen: []}])), japan: {completed: '2026-10-01T00:00:00Z', started: '2026-10-07T00:00:00Z', pending: queue, seen: []}}};
      await writeFile(join(root, 'responses.json'), JSON.stringify(responses));
      await writeFile(join(root, 'previous/state.json'), JSON.stringify(prior));
      await writeFile(join(root, 'previous', pipeline.tableFile), gzipSync(previous));
      await writeFile(join(root, 'requests.ndjson'), '');
      await writeFile(join(root, 'events.ndjson'), '');
      await writeFile(join(root, 'github-output'), '');
      const child = spawnSync(process.execPath, ['--import', join(root, 'mock.mjs'), join(root, 'scripts', pipeline.script)], {
        cwd: root, encoding: 'utf8', timeout: 30_000, env: {...process.env,
          PREVIOUS_DATA: join(root, 'previous'), OVERPASS_URL: 'https://overpass.invalid/test',
          BUDGET_BYTES: '20000000', DAY_BUDGET_BYTES: '30000000',
          MOCK_EVENTS: join(root, 'events.ndjson'), MOCK_PATH: join(root, 'responses.json'), MOCK_LOG: join(root, 'requests.ndjson'), GITHUB_OUTPUT: join(root, 'github-output')},
      });
      assert.equal(child.status, 0, `${child.error ?? ''}\n${child.stderr}`);
      const saved = JSON.parse(await readFile(join(root, pipeline.folder, 'state.json'), 'utf8'));
      return {events: (await readFile(join(root, 'events.ndjson'), 'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse), saved, attempt: saved.stages.japan.lastAttempt,
        requests: (await readFile(join(root, 'requests.ndjson'), 'utf8')).trim().split('\n').map(JSON.parse),
        table: gunzipSync(await readFile(join(root, pipeline.folder, pipeline.tableFile))).toString(),
        output: await readFile(join(root, 'github-output'), 'utf8')};
    };
    await fn(run, initial);
  } finally {await rm(root, {recursive: true, force: true});}
}

const deferred = (result, initial, bytes, requests) => {
  assert.equal(result.attempt.splitBoxes, 0, 'exhausted allowance is not evidence of an oversized region');
  assert.equal(result.attempt.fetchedBoxes, 0);
  assert.equal(result.attempt.status, 'deferred');
  assert.match(result.attempt.reason, /download budget reached/);
  assert.equal(result.attempt.downloadedBytes, bytes);
  assert.equal(result.requests.length, requests);
  assert.equal(new Set(result.requests.map(item => item.query)).size, 1, 'retries retain the original region');
  assert.deepEqual(result.saved.stages.japan.pending, queue, 'the whole pending queue and split depth stay intact');
  assert.equal(result.table, initial, 'accepted geometry and membership stay intact');
  assert.equal(result.output, 'publish=true\nredeploy=false\n');
};


const assertStream = (result, bytes, canceled = true, request = 0) => {
  const events = result.events.filter(event => event.request === request);
  assert.equal(events.filter(event => event.kind === 'chunk').reduce((sum, event) => sum + event.length, 0), bytes);
  assert.equal(events.filter(event => event.kind === 'cancel').length, Number(canceled));
  assert.equal(events.filter(event => event.kind === 'close').length, Number(!canceled));
};
const assertSplit = (result, bytes) => {
  assert.equal(result.attempt.splitBoxes, 1); assert.equal(result.attempt.fetchedBoxes, 0);
  assert.equal(result.attempt.downloadedBytes, bytes);
  assert.deepEqual(result.saved.stages.japan.pending, [...quarters(queue[0].box).map(box => ({part: 0, box, depth: 2})), queue[1]]);
};
for (const pipeline of pipelines) {
  for (const status of [400, 401, 403, 429, 500, 502, 503, 504]) {
    test(`${pipeline.name}: chunked HTTP ${status} cannot cause subdivision; cancels without draining`, async () => fixture(pipeline, async (run, initial) => {
      const result = await run([{status, text:'Gateway Timeout: server at capacity; request queue is full.', bytes: 30_000_000, chunks: [19_999_999, 1, 1, 10_000_000]}]);
      deferred(result, initial, 20_000_001, 1); assertStream(result, 20_000_001);
    }));
  }
  test(`${pipeline.name}: successful one-byte crossing after exact full-run boundary still splits`, async () => fixture(pipeline, async run => {
    const result = await run([{body, bytes: 30_000_000, chunks: [19_999_999, 1, 1, 10_000_000]}]);
    assertSplit(result, 20_000_001); assertStream(result, 20_000_001);
  }));
  test(`${pipeline.name}: successful stream crossing full-run budget in 64 KiB chunks still splits`, async () => fixture(pipeline, async run => {
    const result = await run([{body, bytes: 30_000_000, chunks: []}]);
    const expected = Math.ceil(20_000_001 / 65536) * 65536;
    assertSplit(result, expected); assertStream(result, expected);
  }));
  test(`${pipeline.name}: reduced daily allowance cancels oversized stream before enough evidence for subdivision`, async () => fixture(pipeline, async (run, initial) => {
    const result = await run([{body, bytes: 30_000_000, chunks: [9_999_999, 1, 1, 20_000_000]}], {runs: [{at: new Date().toISOString(), bytes: 20_000_000}]});
    deferred(result, initial, 10_000_001, 1); assertStream(result, 10_000_001);
  }));
  test(`${pipeline.name}: reduced daily allowance still splits if one delivered chunk proves true full-run oversize`, async () => fixture(pipeline, async run => {
    const result = await run([{body, bytes: 30_000_000, chunks: [20_000_001, 10_000_000]}], {runs: [{at: new Date().toISOString(), bytes: 20_000_000}]});
    assertSplit(result, 20_000_001); assertStream(result, 20_000_001);
  }));
  test(`${pipeline.name}: prior failed bytes and streamed crossing retain original queue`, async () => fixture(pipeline, async (run, initial) => {
    const result = await run([{status: 503, text:'Service unavailable', bytes: 1_000_000}, {body, bytes: 30_000_000, chunks: [19_000_000, 1, 10_000_000]}]);
    deferred(result, initial, 20_000_001, 2); assertStream(result, 19_000_001, true, 1);
  }));
  test(`${pipeline.name}: prior failed bytes do not block independent full-run oversize evidence`, async () => fixture(pipeline, async run => {
    const result = await run([{status:503, text:'Service unavailable', bytes:1_000_000}, {body, bytes:30_000_000, chunks:[20_000_001, 10_000_000]}]);
    assertSplit(result, 21_000_001); assertStream(result, 20_000_001, true, 1);
  }));
  test(`${pipeline.name}: exact full-run streamed response closes and is accepted`, async () => fixture(pipeline, async run => {
    const result = await run([{body, bytes:20_000_000, chunks:[19_999_999, 1]}]);
    assert.equal(result.attempt.fetchedBoxes, 1); assert.equal(result.attempt.splitBoxes, 0);
    assert.equal(result.attempt.downloadedBytes, 20_000_000); assert.equal(result.requests.length, 1);
    assert.deepEqual(result.saved.stages.japan.pending, [queue[1]]); assertStream(result, 20_000_000, false);
  }));
  for (const failure of [
    {status:504, text:'Query timed out after 181 seconds.'},
    {body:{remark:'runtime error: Query timed out in query at line 1 after 181 seconds.'}},
    {body:{remark:'runtime error: Query run out of memory using about 2048 MB of RAM.'}},
    {text:'{"elements":['},
  ]) {
    test(`${pipeline.name}: ordinary query timeout/memory/truncated JSON still subdivides (${JSON.stringify(failure)})`, async () => fixture(pipeline, async run => {
      const result = await run([failure, ...Array.from({length:5}, () => ({body}))]);
      assert.equal(result.attempt.splitBoxes, 1); assert.equal(result.attempt.fetchedBoxes, 5);
      assert.equal(result.requests.length, 6); assert.equal(result.saved.stages.japan.pending, null);
    }));
  }
  test(`${pipeline.name}: oversized stream after a genuine split defers the pending child`, async () => fixture(pipeline, async run => {
    const failure = {status:504, text:'Query timed out after 181 seconds.'};
    const result = await run([failure, {body, bytes:30_000_000, chunks:[20_000_001, 10_000_000]}]);
    assertSplit(result, Buffer.byteLength(failure.text) + 20_000_001);
    assertStream(result, 20_000_001, true, 1); assert.equal(result.requests.length, 2);
  }));
  test(`${pipeline.name}: repeated genuine query timeouts retain depth-six leaf`, async () => fixture(pipeline, async run => {
    const result = await run(Array.from({length:6}, () => ({status:504, text:'Query timed out after 181 seconds.'})));
    assert.equal(result.attempt.splitBoxes, 5); assert.equal(result.attempt.fetchedBoxes, 0);
    assert.equal(result.saved.stages.japan.pending[0].depth, 6);
    assert.equal(result.requests.length, 6); assert.match(result.attempt.reason, /could not fetch region/);
  }));
}
