import test from 'node:test';
import assert from 'node:assert/strict';
import {cp, mkdir, mkdtemp, readFile, rm, symlink, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join, resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
import {gzipSync, gunzipSync} from 'node:zlib';
import {STAGES, quarters, toFeatures, writeTable as writeBranches} from '/workspace/shared/atlas-next-bug-20261017/source/scripts/branch-lines.mjs';
import {addResult, commitStage, toTable, writeTable as writeServices} from '/workspace/shared/atlas-next-bug-20261017/source/scripts/service-routes.mjs';

const body = {osm3s: {timestamp_osm_base: '2026-10-07T00:00:00Z'}, elements: [
  {type: 'relation', id: 1, version: 1, timestamp: '2026-10-01T00:00:00Z',
    tags: {route: 'subway', ref: '1', name: 'Fixture line', network: 'Fixture'},
    members: [{type: 'way', ref: 10, role: ''}]},
  {type: 'way', id: 10, version: 1, timestamp: '2026-10-01T00:00:00Z',
    tags: {railway: 'subway'}, nodes: [1, 2], geometry: [{lon: 139.7, lat: 35.68}, {lon: 139.71, lat: 35.69}]},
]};
const part = STAGES.find(stage => stage.name === 'japan').parts[0];
const queue = quarters(part.box).slice(0, 2).map(box => ({part: 0, box, depth: 1}));
const pipelines = [
  {name: 'service', script: 'build-service-routes.mjs', folder: 'service-data', tableFile: 'service-routes.ndjson.gz', version: 1,
    table: () => {const table = {routes: new Map(), ways: new Map()}; addResult(table, toTable(body), 'japan'); commitStage(table, 'japan'); return writeServices(table);}},
  {name: 'branch', script: 'build-branch-lines.mjs', folder: 'branch-data', tableFile: 'branch-lines.ndjson.gz', version: 3,
    table: () => writeBranches(new Map(toFeatures(body).map(feature => [feature.id, {...feature, stage: 'japan'}])))},
];

async function fixture(pipeline, fn) {
  const root = await mkdtemp(join(tmpdir(), 'atlas-staged-budget-'));
  try {
    await cp('scripts', join(root, 'scripts'), {recursive: true});
    await mkdir(join(root, 'styles'));
    for (const name of ['pbf-utf8.mjs', 'service-frequency.mjs']) await cp(`styles/${name}`, join(root, 'styles', name));
    await symlink(resolve('node_modules'), join(root, 'node_modules'), 'dir');
    await mkdir(join(root, 'previous'));
    await writeFile(join(root, 'mock.mjs'), `import {readFileSync, appendFileSync} from 'node:fs';
const observations = JSON.parse(readFileSync(process.env.MOCK_PATH, 'utf8')); let count = 0;
const log = event => appendFileSync(process.env.MOCK_EVENTS, JSON.stringify(event) + '\\n');
globalThis.setTimeout = callback => {callback(); return 0;};
globalThis.fetch = async (url, options) => {
  appendFileSync(process.env.MOCK_LOG, JSON.stringify({url, query: options.body.get('data')}) + '\\n');
  const request = count, next = observations[count++]; if (!next) throw new Error('Unexpected fixture request');
  if (next.throw) throw new Error(next.throw);
  const text = next.text ?? JSON.stringify(next.body);
  const buffer = Buffer.from(text.padEnd(next.bytes ?? text.length, ' '));
  if (!next.chunks) return new Response(buffer, {status: next.status ?? 200});
  let offset = 0, chunkIndex = 0;
  return new Response(new ReadableStream({
    pull(controller) {
      if (offset >= buffer.length) { log({request, kind: 'close'}); controller.close(); return; }
      const length = Math.min(next.chunks[chunkIndex++] ?? next.chunkSize ?? 65536, buffer.length - offset);
      log({request, kind: 'chunk', length});
      controller.enqueue(buffer.subarray(offset, offset + length)); offset += length;
    },
    cancel() { log({request, kind: 'cancel', offset}); },
  }, {highWaterMark: 0}), {status: next.status ?? 200});
};`);
    const initial = pipeline.table();
    const run = async (responses, {runs = [], state, previous = initial} = {}) => {
      const prior = state ?? {version: pipeline.version, downloadStages: 3, runs,
        stages: {...Object.fromEntries(STAGES.map(stage => [stage.name, {completed: new Date().toISOString(), pending: null, seen: []}])), japan: {completed: '2026-10-01T00:00:00Z', started: '2026-10-07T00:00:00Z', pending: queue, seen: []}}};
      await writeFile(join(root, 'responses.json'), JSON.stringify(responses));
      await writeFile(join(root, 'previous/state.json'), JSON.stringify(prior));
      await writeFile(join(root, 'previous', pipeline.tableFile), gzipSync(previous));
      await writeFile(join(root, 'requests.ndjson'), '');
      await writeFile(join(root, 'events.ndjson'), '');
      await writeFile(join(root, 'github-output'), '');
      const child = spawnSync(process.execPath, ['--import', join(root, 'mock.mjs'), join(root, 'scripts', pipeline.script)], {
        cwd: root, encoding: 'utf8', timeout: 30_000, env: {...process.env,
          PREVIOUS_DATA: join(root, 'previous'), OVERPASS_URL: 'https://overpass.invalid/test',
          BUDGET_BYTES: '20000000', DAY_BUDGET_BYTES: '30000000',
          MOCK_EVENTS: join(root, 'events.ndjson'), MOCK_PATH: join(root, 'responses.json'), MOCK_LOG: join(root, 'requests.ndjson'), GITHUB_OUTPUT: join(root, 'github-output')},
      });
      assert.equal(child.status, 0, `${child.error ?? ''}\n${child.stderr}`);
      const saved = JSON.parse(await readFile(join(root, pipeline.folder, 'state.json'), 'utf8'));
      return {events: (await readFile(join(root, 'events.ndjson'), 'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse), saved, attempt: saved.stages.japan.lastAttempt,
        requests: (await readFile(join(root, 'requests.ndjson'), 'utf8')).trim().split('\n').map(JSON.parse),
        table: gunzipSync(await readFile(join(root, pipeline.folder, pipeline.tableFile))).toString(),
        output: await readFile(join(root, 'github-output'), 'utf8')};
    };
    await fn(run, initial);
  } finally {await rm(root, {recursive: true, force: true});}
}

const deferred = (result, initial, bytes, requests) => {
  assert.equal(result.attempt.splitBoxes, 0, 'exhausted allowance is not evidence of an oversized region');
  assert.equal(result.attempt.fetchedBoxes, 0);
  assert.equal(result.attempt.status, 'deferred');
  assert.match(result.attempt.reason, /download budget reached/);
  assert.equal(result.attempt.downloadedBytes, bytes);
  assert.equal(result.requests.length, requests);
  assert.equal(new Set(result.requests.map(item => item.query)).size, 1, 'retries retain the original region');
  assert.deepEqual(result.saved.stages.japan.pending, queue, 'the whole pending queue and split depth stay intact');
  assert.equal(result.table, initial, 'accepted geometry and membership stay intact');
  assert.equal(result.output, 'publish=true\nredeploy=false\n');
};



for (const pipeline of pipelines) {
  for (const [allowance, runs] of [[20_000_000, []], [10_000_000, [{at: new Date().toISOString(), bytes: 20_000_000}]]]) {
    test(`${pipeline.name}: observe existing exact-limit HTTP 503 retry at allowance ${allowance}`, async () => fixture(pipeline, async run => {
      const result = await run([{status:503, text:'Service unavailable', bytes:allowance, chunks:[]}, {body, bytes:1_000_000}], {runs});
      console.log(JSON.stringify({pipeline:pipeline.name, allowance, requests:result.requests.length, downloaded:result.attempt.downloadedBytes, splitBoxes:result.attempt.splitBoxes}));
      assert.equal(result.requests.length, 2, 'Existing retry loop has no budget guard after exactly consuming the allowance');
      assert.equal(result.attempt.downloadedBytes, allowance + 1_000_000);
    }));
  }
}
