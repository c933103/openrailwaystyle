# Preserve queued regions when download allowance is exhausted

Bounded correction for [#108](https://github.com/c933103/openrailwaystyle/issues/108), based on main `7defb0ffdd6d6dddb570407369227b9c27f0e657`. The broader worldwide acquisition and source-coverage acceptance remains open.

## Reproduction and cause

The Service and branch acquisition builders both returned the spatial-subdivision signal whenever their first response exceeded the *remaining* run/daily byte allowance. That happened before checking HTTP status, and the comparison included bytes spent on earlier failed attempts. Offline actual-builder fixtures reproduce unwanted subdivision for HTTP 429/502/503/504 response bodies, reduced rolling-day balance and a fitting successful response following a failed attempt. The final 20-test matrix on unchanged production source yields **12 expected failures / 8 passing controls**.

This is a reproducible processing defect, not a claim that these exact synthetic payloads occurred during a particular production run. The existing documented capacity-failure and resumable-queue requirements provide the scope.

## Correction

Keep the original queued box unless an HTTP-success response, before any accepted or split box, independently exceeds the configured full-run allowance. Every received byte still counts. Actual full-run oversize, exact-boundary acceptance, partial progress, ordinary timeout/memory subdivision, and the existing retry/refresh policies are retained. Apply the identical bounded correction to the two builders that share this decision. Update the maintenance contract.

No provider limits, workflow triggers, cadence, query selectors, map runtime, geometry or published datasets change.

## Validation

Environment: Node v24.19.0, existing pinned dependencies; no package changes or installation.

- Final baseline negative control: `node --test tests/staged-acquisition-budget.test.mjs`, **12 fail / 8 pass**, solely because the old implementation subdivides when it should defer.
- Final focused: `node --test tests/staged-acquisition-budget.test.mjs tests/service-geometry-acquisition.test.mjs tests/branch-lines.test.mjs`, **60/60 pass**.
- Aggregate: `npm test`, **2,190/2,190 pass**, no failures, cancellations or skips. This includes all 20 expanded new regressions.
- `npm run build`, generated style/station reproducibility, source syntax and `git diff --check`: **pass**.
- The tests retain accepted table bytes, exact pending queues/depths, total failed/successful byte accounting, deferred publication and next-eligible-run resumption. Exact-limit and successful oversize controls pass. Existing genuine query-timeout/memory behavior remains covered.
- No browser run: this change is acquisition-only and changes no rendering. Hosted required CI remains binding.

The first resumption-test fixture left other stages unfinished; the scheduler correctly chose one of those stages instead of Japan. The fixture now explicitly marks unrelated stages complete so it tests resuming the sole pending queue. That initial 2-test harness failure is preserved in `focused.log`; production code was unchanged by the fixture correction.

Application/source bytes were checked against the complete untruncated Git tree. The local test snapshot omits only 177 archival investigation files and an unrelated logo image. It includes all runtime sources, scripts, tests and required fixtures. The patch modifies four files only; compact byte identities are in `receipt.json` and `source-verification.json`.

Prepared and locally tested only. No provider request, workflow dispatch, source publication, code-review claim, merge or deployment was performed. Do not close #108 or the broader parent issues on this bounded correction.
